import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Widgets

WlrLayershell {
    id: picker
    layer: WlrLayer.Overlay
    namespace: "wall-picker"
    exclusiveZone: 0
    color: "transparent"
    visible: wallPickerOpen

    keyboardFocus: WlrKeyboardFocus.Exclusive

    anchors.top: true
    anchors.right: true
    anchors.bottom: true
    anchors.left: true

    // ─── Данные ───────────────────────────────────────────────────
    property string bin: Quickshell.env("HOME") + "/.config/quickshell/wallpaper/wallpaper-picker"

    property var imageData:  []
    property var videoData:  []
    property var shaderData: []

    property bool loadingImages:  false
    property bool loadingVideos:  false
    property bool loadingShaders: false

    // 0 = Static, 1 = Видео, 2 = Shader
    property int activeTab: 0
    property string searchTerm: ""

    property var filteredImages: {
        var t = searchTerm.toLowerCase()
        if (!t) return imageData
        return imageData.filter(function(w) { return w.name.toLowerCase().indexOf(t) !== -1 })
    }
    property var filteredVideos: {
        var t = searchTerm.toLowerCase()
        if (!t) return videoData
        return videoData.filter(function(w) { return w.name.toLowerCase().indexOf(t) !== -1 })
    }
    property var filteredShaders: {
        var t = searchTerm.toLowerCase()
        if (!t) return shaderData
        return shaderData.filter(function(s) { return s.name.toLowerCase().indexOf(t) !== -1 })
    }

    function closePicker() {
        searchField.text = ""
        wallPickerOpen = false
    }

    // ─── Восстановление состояния при старте ──────────────────────
    Process {
        id: stateProc
        running: false
        command: [picker.bin, "get-state"]
        stdout: StdioCollector {
            onStreamFinished: {
                var raw = text.trim()
                if (!raw) return
                try {
                    var s = JSON.parse(raw)
                    wallpaperType = s.wallType
                    if (s.shader && s.shader !== "") wallShaderName = s.shader
                    if      (s.mode === "video")  picker.activeTab = 1
                    else if (s.mode === "shader") picker.activeTab = 2
                    else                          picker.activeTab = 0
                } catch(e) { console.warn("[WallPicker] get-state parse error:", e) }
            }
        }
        stderr: SplitParser { onRead: data => console.warn("[WallPicker] get-state stderr:", data) }
    }

    Component.onCompleted: { stateProc.running = false; stateProc.running = true }

    // ─── Процессы загрузки ────────────────────────────────────────
    Process {
        id: imageProc; running: false
        command: [picker.bin, "list-images"]
        stdout: StdioCollector {
            onStreamFinished: {
                picker.loadingImages = false
                var raw = text.trim(); if (!raw) return
                try { picker.imageData = JSON.parse(raw) }
                catch(e) { console.warn("[WallPicker] list-images:", e) }
            }
        }
        stderr: SplitParser { onRead: d => console.warn("[WallPicker] list-images stderr:", d) }
    }

    Process {
        id: videoProc; running: false
        command: [picker.bin, "list-videos"]
        stdout: StdioCollector {
            onStreamFinished: {
                picker.loadingVideos = false
                var raw = text.trim(); if (!raw) return
                try { picker.videoData = JSON.parse(raw) }
                catch(e) { console.warn("[WallPicker] list-videos:", e) }
            }
        }
        stderr: SplitParser { onRead: d => console.warn("[WallPicker] list-videos stderr:", d) }
    }

    Process {
        id: shaderProc; running: false
        command: [picker.bin, "list-shaders"]
        stdout: StdioCollector {
            onStreamFinished: {
                picker.loadingShaders = false
                var raw = text.trim(); if (!raw) return
                try { picker.shaderData = JSON.parse(raw) }
                catch(e) { console.warn("[WallPicker] list-shaders:", e) }
            }
        }
        stderr: SplitParser { onRead: d => console.warn("[WallPicker] list-shaders stderr:", d) }
    }

    Process { id: setProc; running: false }

    Process {
        id: cacheProc; running: false
        command: [picker.bin, "cache-all"]
        onExited: (code, _) => { if (code === 0) reloadAll() }
    }

    // Флаги — грузим каждый таб только один раз за сессию открытия
    property bool imagesLoaded:  false
    property bool videosLoaded:  false
    property bool shadersLoaded: false

    function loadTab(tab) {
        if (tab === 0 && !imagesLoaded) {
            picker.imageData = []; picker.loadingImages = true
            imagesLoaded = true
            imageProc.running = false; imageProc.running = true
        } else if (tab === 1 && !videosLoaded) {
            picker.videoData = []; picker.loadingVideos = true
            videosLoaded = true
            videoProc.running = false; videoProc.running = true
        } else if (tab === 2 && !shadersLoaded) {
            picker.shaderData = []; picker.loadingShaders = true
            shadersLoaded = true
            shaderProc.running = false; shaderProc.running = true
        }
    }

    function reloadAll() {
        picker.imageData = []; picker.videoData = []; picker.shaderData = []
        picker.loadingImages = false; picker.loadingVideos = false; picker.loadingShaders = false
        imagesLoaded = false; videosLoaded = false; shadersLoaded = false
        loadTab(picker.activeTab)
    }

    onActiveTabChanged: loadTab(activeTab)

    onVisibleChanged: {
        if (visible) {
            searchField.text = ""; picker.searchTerm = ""
            reloadAll()
            searchField.forceActiveFocus()
        }
    }

    MouseArea { anchors.fill: parent; onClicked: picker.closePicker() }

    // ═══════════════════════════════════════════════════════════════
    // ПАНЕЛЬ — тот же градиентный фон что у бара, отступ 6px сверху
    // ═══════════════════════════════════════════════════════════════
    Rectangle {
        id: panel
        width: 900
        height: 640
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.topMargin: 6
        anchors.leftMargin: 6
        radius: mainRad

        // Слой 1: градиент как у бара (opacity 0.85)
        Rectangle {
            anchors.fill: parent
            radius: parent.radius
            opacity: 0.92
            gradient: Gradient {
                orientation: Gradient.Horizontal
                GradientStop { position: 0.0;  color: col.background3 }
                GradientStop { position: 0.05; color: col.background2 }
                GradientStop { position: 0.3;  color: col.background1 }
                GradientStop { position: 0.7;  color: col.background1 }
                GradientStop { position: 0.95; color: col.background2 }
                GradientStop { position: 1.0;  color: col.background3 }
            }
        }

        MouseArea { anchors.fill: parent; onClicked: {} }

        // Внутренний контейнер с margin 3 — как у бара
        Item {
            anchors.fill: parent
            anchors.margins: 3

            ColumnLayout {
                anchors.fill: parent
                spacing: 3

                // ══ СТРОКА ЗАГОЛОВКА ════════════════════════════════
                // Весь заголовок — одна «пилюля» в стиле бара
                Item {
                    Layout.fillWidth: true
                    height: 30

                    // Внешний градиент — как все чипы в баре
                    Rectangle {
                        anchors.fill: parent
                        radius: mainRad - 3
                        opacity: 0.65
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0.0;   color: col.backgroundAlt2 }
                            GradientStop { position: 0.275; color: col.backgroundAlt1 }
                            GradientStop { position: 0.725; color: col.backgroundAlt1 }
                            GradientStop { position: 1.0;   color: col.backgroundAlt2 }
                        }
                    }

                    Row {
                        anchors.fill: parent
                        anchors.margins: 3
                        spacing: 3

                        // Иконка + название
                        Row {
                            height: parent.height
                            spacing: 6
                            anchors.verticalCenter: parent.verticalCenter

                            Text {
                                text: "󰸉"
                                color: col.accent
                                font.family: "Mononoki Nerd Font Propo"
                                font.pixelSize: 17
                                font.weight: Font.Bold
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            Text {
                                text: "обои"
                                color: col.font
                                font.family: "Mononoki Nerd Font Propo"
                                font.pixelSize: 17
                                font.weight: Font.Bold
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }

                        // Растяжка
                        Item { width: parent.width - 2*(30) - 6 - 80; height: 1 }

                        // Кнопка: обновить кэш превью
                        Item {
                            width: 30; height: parent.height

                            Rectangle {
                                id: cacheBg
                                anchors.fill: parent
                                anchors.margins: 2
                                radius: mainRad - 5
                                color: "transparent"
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }
                            Text {
                                id: cacheIcon
                                anchors.centerIn: parent
                                text: cacheProc.running ? "󰑓" : "󰑐"
                                color: col.font
                                font.family: "Mononoki Nerd Font Propo"
                                font.pixelSize: 17
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: { cacheBg.color = col.accent; cacheIcon.color = col.fontDark }
                                onExited:  { cacheBg.color = "transparent"; cacheIcon.color = col.font }
                                onClicked: { if (!cacheProc.running) { cacheProc.running = false; cacheProc.running = true } }
                            }
                        }

                        // Кнопка: закрыть
                        Item {
                            width: 30; height: parent.height

                            Rectangle {
                                id: closeBg
                                anchors.fill: parent
                                anchors.margins: 2
                                radius: mainRad - 5
                                color: "transparent"
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }
                            Text {
                                id: closeIcon
                                anchors.centerIn: parent
                                text: "󰅙"
                                color: col.font
                                font.family: "Mononoki Nerd Font Propo"
                                font.pixelSize: 17
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: { closeBg.color = "#c0392b"; closeIcon.color = "#ffffff" }
                                onExited:  { closeBg.color = "transparent"; closeIcon.color = col.font }
                                onClicked: picker.closePicker()
                            }
                        }
                    }
                }

                // ══ СТРОКА ТАБОВ + ПОИСК ════════════════════════════
                Item {
                    Layout.fillWidth: true
                    height: 30

                    Row {
                        anchors.left: parent.left
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 3

                        // Три таба — каждый пилюля в стиле бара
                        Repeater {
                            model: [
                                { label: "  Static", icon: "󰸉", wallTypeVal: 1 },
                                { label: "  Видео",  icon: "󰨜", wallTypeVal: 3 },
                                { label: "  Shader", icon: "󰔯", wallTypeVal: 2 },
                            ]

                            Item {
                                width: tabRow.width + 20
                                height: 30

                                // Внешний градиент (всегда)
                                Rectangle {
                                    anchors.fill: parent
                                    radius: mainRad - 3
                                    opacity: 0.65
                                    gradient: Gradient {
                                        orientation: Gradient.Horizontal
                                        GradientStop { position: 0.0;   color: col.backgroundAlt2 }
                                        GradientStop { position: 0.275; color: col.backgroundAlt1 }
                                        GradientStop { position: 0.725; color: col.backgroundAlt1 }
                                        GradientStop { position: 1.0;   color: col.backgroundAlt2 }
                                    }
                                }

                                // Внутренний фон — акцент если активен, hover иначе
                                Rectangle {
                                    id: tabBg
                                    anchors.fill: parent
                                    anchors.margins: 2
                                    radius: mainRad - 5
                                    color: picker.activeTab === index ? col.accent : "transparent"
                                    Behavior on color { ColorAnimation { duration: 200 } }
                                }

                                Row {
                                    id: tabRow
                                    anchors.centerIn: parent
                                    spacing: 5

                                    Text {
                                        id: tabText
                                        text: modelData.label
                                        color: picker.activeTab === index ? col.fontDark : col.font
                                        font.family: "Mononoki Nerd Font Propo"
                                        font.pixelSize: 15
                                        font.weight: Font.Bold
                                        anchors.verticalCenter: parent.verticalCenter
                                        Behavior on color { ColorAnimation { duration: 200 } }
                                    }

                                    // Точка — этот режим сейчас активен в системе
                                    Rectangle {
                                        visible: wallpaperType === modelData.wallTypeVal
                                        width: 5; height: 5; radius: 3
                                        color: picker.activeTab === index ? col.fontDark : col.accent
                                        anchors.verticalCenter: parent.verticalCenter
                                    }
                                }

                                MouseArea {
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onEntered: {
                                        if (picker.activeTab !== index) {
                                            tabBg.color = col.backgroundAlt1
                                            tabText.color = col.font
                                        }
                                    }
                                    onExited: {
                                        if (picker.activeTab !== index) {
                                            tabBg.color = "transparent"
                                        }
                                    }
                                    onClicked: picker.activeTab = index
                                }
                            }
                        }
                    }

                    // Поиск — справа, пилюля в стиле бара
                    Item {
                        width: 200
                        height: 30
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter

                        Rectangle {
                            anchors.fill: parent
                            radius: mainRad - 3
                            opacity: 0.65
                            gradient: Gradient {
                                orientation: Gradient.Horizontal
                                GradientStop { position: 0.0;   color: col.backgroundAlt2 }
                                GradientStop { position: 0.275; color: col.backgroundAlt1 }
                                GradientStop { position: 0.725; color: col.backgroundAlt1 }
                                GradientStop { position: 1.0;   color: col.backgroundAlt2 }
                            }
                        }

                        Rectangle {
                            id: searchBg
                            anchors.fill: parent
                            anchors.margins: 2
                            radius: mainRad - 5
                            color: "transparent"
                            Behavior on color { ColorAnimation { duration: 200 } }
                        }

                        Row {
                            anchors.fill: parent
                            anchors.leftMargin: 8
                            anchors.rightMargin: 8
                            spacing: 6
                            anchors.verticalCenter: parent.verticalCenter

                            Text {
                                id: searchIcon
                                text: "󰍉"
                                color: col.accent
                                font.family: "Mononoki Nerd Font Propo"
                                font.pixelSize: 17
                                font.weight: Font.Bold
                                anchors.verticalCenter: parent.verticalCenter
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }

                            Item {
                                width: parent.width - searchIcon.width - 6
                                height: parent.height
                                anchors.verticalCenter: parent.verticalCenter

                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: "поиск..."
                                    color: col.backgroundAlt2
                                    font.family: "Mononoki Nerd Font Propo"
                                    font.pixelSize: 15
                                    visible: searchField.text.length === 0
                                }

                                TextInput {
                                    id: searchField
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width
                                    color: col.font
                                    font.family: "Mononoki Nerd Font Propo"
                                    font.pixelSize: 15
                                    clip: true
                                    onTextChanged: picker.searchTerm = text
                                    Keys.onEscapePressed: picker.closePicker()
                                }
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            onEntered: { searchBg.color = col.backgroundAlt1; searchIcon.color = col.font }
                            onExited:  { searchBg.color = "transparent"; searchIcon.color = col.accent }
                            onClicked: searchField.forceActiveFocus()
                        }
                    }
                }

                // ══ КОНТЕНТ — один ClippingRectangle, внутри Loader ══
                // Loader полностью уничтожает неактивный таб из дерева —
                // никаких невидимых MouseArea, никакой конкуренции в Layout
                ClippingRectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    radius: mainRad - 5
                    color: "transparent"

                    Loader {
                        id: contentLoader
                        anchors.fill: parent
                        sourceComponent: picker.activeTab === 2 ? shaderComp : gridComp
                    }
                }

                // ── Компонент: грид обоев (Static + Видео) ────────────
                Component {
                    id: gridComp
                    GridView {
                        id: wallGrid
                        anchors.fill: parent
                        clip: true
                        // Рендерим только видимые — без буфера за краями
                        cacheBuffer: 0
                        cellWidth:  Math.floor(width / 3)
                        cellHeight: Math.floor(cellWidth * 9/21) + 30

                        model: picker.activeTab === 0 ? picker.filteredImages : picker.filteredVideos

                        property bool isLoading: picker.activeTab === 0
                            ? picker.loadingImages : picker.loadingVideos

                        Text {
                            anchors.centerIn: parent
                            visible: wallGrid.count === 0
                            text: wallGrid.isLoading ? "󰑐  загрузка..."
                                : (picker.activeTab === 0 ? "󰸉  нет картинок" : "󰨜  нет видео")
                            color: col.backgroundAlt2
                            font.family: "Mononoki Nerd Font Propo"
                            font.pixelSize: 15
                            font.weight: Font.Bold
                        }

                        delegate: Item {
                            width: wallGrid.cellWidth
                            height: wallGrid.cellHeight

                            Item {
                                anchors.fill: parent
                                anchors.margins: 2

                                Rectangle {
                                    anchors.fill: parent
                                    radius: mainRad - 3
                                    opacity: 0.65
                                    gradient: Gradient {
                                        orientation: Gradient.Horizontal
                                        GradientStop { position: 0.0;   color: col.backgroundAlt2 }
                                        GradientStop { position: 0.275; color: col.backgroundAlt1 }
                                        GradientStop { position: 0.725; color: col.backgroundAlt1 }
                                        GradientStop { position: 1.0;   color: col.backgroundAlt2 }
                                    }
                                }

                                ClippingRectangle {
                                    id: cardInner
                                    anchors.fill: parent
                                    anchors.margins: 2
                                    radius: mainRad - 5
                                    color: "transparent"
                                    Behavior on color { ColorAnimation { duration: 200 } }

                                    ClippingRectangle {
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        anchors.top: parent.top
                                        height: Math.floor(parent.width * 9/21)
                                        radius: mainRad - 5

                                        Image {
                                            id: thumbImg
                                            anchors.fill: parent
                                            source: modelData.thumb !== "" ? ("file://" + modelData.thumb) : ""
                                            fillMode: Image.PreserveAspectCrop
                                            asynchronous: true
                                            // КРИТИЧНО: ограничиваем размер загружаемой текстуры
                                            // без этого QML грузит полный файл превью в память
                                            sourceSize.width: 320
                                            sourceSize.height: 180
                                            opacity: cardMa.containsMouse ? 0.75 : 1.0
                                            Behavior on opacity { NumberAnimation { duration: 200 } }

                                            Rectangle {
                                                anchors.fill: parent
                                                color: col.background1
                                                visible: parent.status !== Image.Ready
                                                Text {
                                                    anchors.centerIn: parent
                                                    text: modelData.type === "video" ? "󰨜" : "󰸉"
                                                    color: col.backgroundAlt2
                                                    font.family: "Mononoki Nerd Font Propo"
                                                    font.pixelSize: 22
                                                }
                                            }
                                        }
                                    }

                                    Item {
                                        visible: modelData.type === "video"
                                        anchors.bottom: parent.bottom
                                        anchors.bottomMargin: 30
                                        anchors.right: parent.right
                                        anchors.margins: 4
                                        width: videoLabel.width + 10
                                        height: 16

                                        Rectangle {
                                            anchors.fill: parent
                                            radius: mainRad - 5
                                            opacity: 0.65
                                            gradient: Gradient {
                                                orientation: Gradient.Horizontal
                                                GradientStop { position: 0.0; color: "#cc2244" }
                                                GradientStop { position: 1.0; color: "#882233" }
                                            }
                                        }
                                        Text {
                                            id: videoLabel
                                            anchors.centerIn: parent
                                            text: "󰨜 VIDEO"
                                            font.family: "Mononoki Nerd Font Propo"
                                            font.pixelSize: 9
                                            font.weight: Font.Bold
                                            color: "#fff"
                                        }
                                    }

                                    Row {
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        anchors.bottom: parent.bottom
                                        anchors.leftMargin: 6
                                        anchors.rightMargin: 6
                                        anchors.bottomMargin: 4
                                        height: 22
                                        spacing: 4

                                        Text {
                                            text: modelData.type === "video" ? "󰨜" : "󰸉"
                                            color: cardMa.containsMouse ? col.fontDark : col.accent
                                            font.family: "Mononoki Nerd Font Propo"
                                            font.pixelSize: 13
                                            anchors.verticalCenter: parent.verticalCenter
                                            Behavior on color { ColorAnimation { duration: 200 } }
                                        }
                                        Text {
                                            width: parent.width - 20
                                            text: modelData.name
                                            color: cardMa.containsMouse ? col.fontDark : col.font
                                            font.family: "Mononoki Nerd Font Propo"
                                            font.pixelSize: 11
                                            font.weight: Font.Bold
                                            elide: Text.ElideRight
                                            anchors.verticalCenter: parent.verticalCenter
                                            Behavior on color { ColorAnimation { duration: 200 } }
                                        }
                                    }
                                }

                                MouseArea {
                                    id: cardMa
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onEntered: cardInner.color = col.accent
                                    onExited:  cardInner.color = "transparent"
                                    onClicked: {
                                        setProc.command = [picker.bin, "set", modelData.path]
                                        setProc.running = false
                                        setProc.running = true
                                        picker.closePicker()
                                    }
                                }
                            }
                        }
                    }
                }

                // ── Компонент: список шейдеров ────────────────────────
                Component {
                    id: shaderComp
                    ListView {
                        id: shaderListView
                        anchors.fill: parent
                        clip: true
                        model: picker.filteredShaders
                        spacing: 3

                        Text {
                            anchors.centerIn: parent
                            visible: shaderListView.count === 0
                            text: picker.loadingShaders ? "󰑐  загрузка..." : "󰔯  шейдеров нет"
                            color: col.backgroundAlt2
                            font.family: "Mononoki Nerd Font Propo"
                            font.pixelSize: 15
                            font.weight: Font.Bold
                        }

                        delegate: Item {
                            width: ListView.view.width
                            height: 34

                            Rectangle {
                                anchors.fill: parent
                                radius: mainRad - 3
                                opacity: 0.65
                                gradient: Gradient {
                                    orientation: Gradient.Horizontal
                                    GradientStop { position: 0.0;   color: col.backgroundAlt2 }
                                    GradientStop { position: 0.275; color: col.backgroundAlt1 }
                                    GradientStop { position: 0.725; color: col.backgroundAlt1 }
                                    GradientStop { position: 1.0;   color: col.backgroundAlt2 }
                                }
                            }

                            Rectangle {
                                id: shaderBg
                                anchors.fill: parent
                                anchors.margins: 2
                                radius: mainRad - 5
                                color: "transparent"
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }

                            Row {
                                anchors.fill: parent
                                anchors.leftMargin: 10
                                anchors.rightMargin: 10
                                spacing: 8

                                Text {
                                    id: shaderIcon
                                    text: "󰔯"
                                    color: col.accent
                                    font.family: "Mononoki Nerd Font Propo"
                                    font.pixelSize: 17
                                    font.weight: Font.Bold
                                    anchors.verticalCenter: parent.verticalCenter
                                    Behavior on color { ColorAnimation { duration: 200 } }
                                }
                                Text {
                                    id: shaderNameText
                                    width: parent.width - shaderIcon.width - activeDot.width - 24
                                    text: modelData.name
                                    color: col.font
                                    font.family: "Mononoki Nerd Font Propo"
                                    font.pixelSize: 15
                                    font.weight: Font.Bold
                                    elide: Text.ElideRight
                                    anchors.verticalCenter: parent.verticalCenter
                                    Behavior on color { ColorAnimation { duration: 200 } }
                                }
                                Rectangle {
                                    id: activeDot
                                    width: 7; height: 7; radius: 4
                                    color: col.accent
                                    anchors.verticalCenter: parent.verticalCenter
                                    visible: wallpaperType === 2 && wallShaderName === modelData.name
                                }
                            }

                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: { shaderBg.color = col.accent; shaderIcon.color = col.fontDark; shaderNameText.color = col.fontDark }
                                onExited:  { shaderBg.color = "transparent"; shaderIcon.color = col.accent; shaderNameText.color = col.font }
                                onClicked: {
                                    setProc.command = [picker.bin, "set-shader", modelData.name]
                                    setProc.running = false
                                    setProc.running = true
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
