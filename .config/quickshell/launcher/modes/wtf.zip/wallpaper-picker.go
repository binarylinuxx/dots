package main

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"

	"github.com/BurntSushi/toml"
)

// ─── Конфиг (wallpaper.toml) ────────────────────────────────────────────────

type Config struct {
	Dirs  DirsConfig  `toml:"dirs"`
	State StateConfig `toml:"state"`
}

type DirsConfig struct {
	ImageDirs []string `toml:"image_dirs"`
	VideoDirs []string `toml:"video_dirs"`
	ShaderDir string   `toml:"shader_dir"`
}

type StateConfig struct {
	Mode      string `toml:"mode"`      // "image" | "video" | "shader"
	Wallpaper string `toml:"wallpaper"` // путь к текущему обою/видео
	Shader    string `toml:"shader"`    // имя текущего шейдера
}

var configPath = homeDir(".config/quickshell/wallpaper/wallpaper.toml")

func homeDir(rel string) string {
	h, _ := os.UserHomeDir()
	return filepath.Join(h, rel)
}

// expandHome раскрывает ~ в начале пути
func expandHome(p string) string {
	if strings.HasPrefix(p, "~/") {
		return filepath.Join(homeDir(""), p[2:])
	}
	return p
}

func loadConfig() Config {
	var cfg Config
	if _, err := toml.DecodeFile(configPath, &cfg); err != nil {
		// Если конфига нет — возвращаем дефолт с пустыми dirs
		// go-скрипт продолжит работу, просто ничего не найдёт
		fmt.Fprintf(os.Stderr, "[wallpaper-picker] cannot read config %s: %v\n", configPath, err)
		return cfg
	}
	// раскрываем ~ во всех путях
	for i, d := range cfg.Dirs.ImageDirs {
		cfg.Dirs.ImageDirs[i] = expandHome(d)
	}
	for i, d := range cfg.Dirs.VideoDirs {
		cfg.Dirs.VideoDirs[i] = expandHome(d)
	}
	cfg.Dirs.ShaderDir = expandHome(cfg.Dirs.ShaderDir)
	cfg.State.Wallpaper = expandHome(cfg.State.Wallpaper)
	return cfg
}

// saveState перезаписывает только секцию [state] в toml-файле.
// Читаем файл целиком, находим [state] блок и заменяем его.
func saveState(mode, wallpaper, shader string) {
	data, err := os.ReadFile(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "[wallpaper-picker] saveState: cannot read config: %v\n", err)
		return
	}

	content := string(data)

	newState := fmt.Sprintf("[state]\nmode        = %q\nwallpaper   = %q\nshader      = %q\n",
		mode, wallpaper, shader)

	// Ищем [state] блок и заменяем до конца файла (он всегда последний)
	idx := strings.Index(content, "\n[state]")
	if idx == -1 {
		idx = strings.Index(content, "[state]")
		if idx == -1 {
			// Блока нет — просто дописываем
			content += "\n" + newState
		} else {
			content = content[:idx] + newState
		}
	} else {
		content = content[:idx+1] + newState
	}

	if err := os.WriteFile(configPath, []byte(content), 0644); err != nil {
		fmt.Fprintf(os.Stderr, "[wallpaper-picker] saveState: cannot write config: %v\n", err)
	}
}

// ─── Кэш-пути ───────────────────────────────────────────────────────────────

var (
	cacheDir    = homeDir(".cache/walls")
	previewDir  = homeDir(".cache/wall_prevs")
	staticCache = filepath.Join(cacheDir, "no-live-bg.jpg")
	videoCache  = filepath.Join(cacheDir, "live-bg.mp4")
	videoFrame  = filepath.Join(cacheDir, "video-frame.jpg")
)

// ─── Типы ───────────────────────────────────────────────────────────────────

type WallEntry struct {
	Path  string `json:"path"`
	Name  string `json:"name"`
	Type  string `json:"type"` // "image" | "video"
	Thumb string `json:"thumb"`
}

type ShaderEntry struct {
	Path string `json:"path"`
	Name string `json:"name"`
}

// StateJSON — выдаётся командой get-state, читается QML/shell.qml при старте
type StateJSON struct {
	Mode      string `json:"mode"`
	Wallpaper string `json:"wallpaper"`
	Shader    string `json:"shader"`
	// WallType — числовой код для wallpaperType в shell.qml
	// 1 = image, 2 = shader, 3 = video, 4 = reset
	WallType int `json:"wallType"`
}

func modeToWallType(mode string) int {
	switch mode {
	case "image":
		return 1
	case "shader":
		return 2
	case "video":
		return 3
	}
	return 1
}

// ─── Сбор файлов ────────────────────────────────────────────────────────────

// collectImages собирает только картинки из image_dirs
func collectImages(cfg Config) []WallEntry {
	return collectByDirs(cfg.Dirs.ImageDirs, map[string]bool{
		".jpg": true, ".jpeg": true, ".png": true, ".webp": true,
	}, "image")
}

// collectVideos собирает только видео из video_dirs
func collectVideos(cfg Config) []WallEntry {
	return collectByDirs(cfg.Dirs.VideoDirs, map[string]bool{
		".mp4": true, ".webm": true, ".mkv": true,
	}, "video")
}

func collectByDirs(dirs []string, exts map[string]bool, kind string) []WallEntry {
	var entries []WallEntry
	idx := len(entries) // для уникального индекса превью используем глобальный счётчик ниже
	_ = idx

	// Используем хэш пути для имени превью — стабильный при перезапуске
	for _, dir := range dirs {
		des, err := os.ReadDir(dir)
		if err != nil {
			continue
		}
		for _, de := range des {
			if de.IsDir() {
				continue
			}
			ext := strings.ToLower(filepath.Ext(de.Name()))
			if !exts[ext] {
				continue
			}
			fullPath := filepath.Join(dir, de.Name())
			// Имя превью — стабильный хэш на основе пути (избегаем пересчёта idx)
			thumb := filepath.Join(previewDir, thumbName(fullPath))
			entries = append(entries, WallEntry{
				Path:  fullPath,
				Name:  de.Name(),
				Type:  kind,
				Thumb: thumb,
			})
		}
	}
	return entries
}

// thumbName — детерминированное имя файла превью по пути оригинала
func thumbName(path string) string {
	// простой djb2-хэш, без зависимостей
	h := uint32(5381)
	for _, c := range path {
		h = h*33 + uint32(c)
	}
	return fmt.Sprintf("thumb_%08x.jpg", h)
}

// ─── Команды ────────────────────────────────────────────────────────────────

// cmdListImages — выдаёт JSON []WallEntry только для картинок
// Опциональные аргументы: offset count (для пагинации)
func cmdListImages(offset, count int) {
	cfg := loadConfig()
	entries := collectImages(cfg)
	entries = paginate(entries, offset, count)
	if entries == nil {
		entries = []WallEntry{}
	}
	out, _ := json.Marshal(entries)
	fmt.Println(string(out))
}

// cmdListVideos — выдаёт JSON []WallEntry только для видео
func cmdListVideos(offset, count int) {
	cfg := loadConfig()
	entries := collectVideos(cfg)
	entries = paginate(entries, offset, count)
	if entries == nil {
		entries = []WallEntry{}
	}
	out, _ := json.Marshal(entries)
	fmt.Println(string(out))
}

// paginate возвращает срез [offset : offset+count].
// count <= 0 означает "все".
func paginate(entries []WallEntry, offset, count int) []WallEntry {
	if offset < 0 {
		offset = 0
	}
	if offset >= len(entries) {
		return []WallEntry{}
	}
	entries = entries[offset:]
	if count > 0 && count < len(entries) {
		entries = entries[:count]
	}
	return entries
}

func cmdListShaders(shaderDirOverride string) {
	cfg := loadConfig()
	shaderDir := cfg.Dirs.ShaderDir
	if shaderDirOverride != "" {
		shaderDir = shaderDirOverride
	}

	des, err := os.ReadDir(shaderDir)
	if err != nil {
		// Не падаем — просто отдаём пустой массив, QML покажет "шейдеров нет"
		fmt.Fprintf(os.Stderr, "shader dir not found: %s\n", shaderDir)
		fmt.Println("[]")
		return
	}

	var shaders []ShaderEntry
	for _, de := range des {
		if de.IsDir() {
			continue
		}
		ext := strings.ToLower(filepath.Ext(de.Name()))
		if ext == ".frag" || ext == ".qsb" {
			shaders = append(shaders, ShaderEntry{
				Path: filepath.Join(shaderDir, de.Name()),
				Name: strings.TrimSuffix(de.Name(), filepath.Ext(de.Name())),
			})
		}
	}

	if shaders == nil {
		shaders = []ShaderEntry{}
	}
	out, _ := json.Marshal(shaders)
	fmt.Println(string(out))
}

// cmdGetState — выдаёт текущее состояние из [state] toml.
// Вызывается QML/shell.qml при старте для восстановления режима.
func cmdGetState() {
	cfg := loadConfig()
	s := StateJSON{
		Mode:      cfg.State.Mode,
		Wallpaper: cfg.State.Wallpaper,
		Shader:    cfg.State.Shader,
		WallType:  modeToWallType(cfg.State.Mode),
	}
	out, _ := json.Marshal(s)
	fmt.Println(string(out))
}

func cmdCacheAll() {
	cfg := loadConfig()
	os.MkdirAll(previewDir, 0755)

	all := append(collectImages(cfg), collectVideos(cfg)...)

	var wg sync.WaitGroup
	sem := make(chan struct{}, 8)

	for _, e := range all {
		if _, err := os.Stat(e.Thumb); err == nil {
			continue // уже есть
		}

		wg.Add(1)
		go func(entry WallEntry) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			var cmd *exec.Cmd
			if entry.Type == "video" {
				cmd = exec.Command("ffmpeg",
					"-ss", "00:00:02",
					"-i", entry.Path,
					"-vframes", "1",
					"-vf", "scale=300:-1",
					"-q:v", "3",
					entry.Thumb, "-y",
				)
			} else {
				cmd = exec.Command("ffmpeg",
					"-i", entry.Path,
					"-vf", "scale=300:-1",
					"-q:v", "3",
					entry.Thumb, "-y",
				)
			}
			cmd.Stderr = nil
			_ = cmd.Run()
		}(e)
	}

	wg.Wait()
	fmt.Println("Cache done!")
}

func cmdCleanCache() {
	os.RemoveAll(previewDir)
	os.MkdirAll(previewDir, 0755)
	fmt.Println("Cache cleaned")
}

func cmdSet(path string) {
	if _, err := os.Stat(path); err != nil {
		fmt.Fprintln(os.Stderr, "file not found:", path)
		os.Exit(1)
	}

	ext := strings.ToLower(filepath.Ext(path))
	isVideo := ext == ".mp4" || ext == ".webm" || ext == ".mkv"

	os.MkdirAll(cacheDir, 0755)

	cfg := loadConfig()

	if isVideo {
		if err := copyFile(path, videoCache); err != nil {
			fmt.Fprintln(os.Stderr, "copy failed:", err)
			os.Exit(1)
		}
		exec.Command("ffmpeg",
			"-ss", "00:00:02",
			"-i", videoCache,
			"-vframes", "1",
			"-vf", "scale=1920:-1",
			"-q:v", "2",
			videoFrame, "-y",
		).Run()

		exec.Command("qs", "ipc", "call", "root", "wallType", "4").Run()
		exec.Command("qs", "ipc", "call", "root", "wallType", "3").Run()

		if _, err := os.Stat(videoFrame); err == nil {
			exec.Command("wallust", "-s", "run", videoFrame).Run()
		}

		saveState("video", path, cfg.State.Shader)

	} else {
		out, _ := exec.Command("ffprobe",
			"-v", "error",
			"-select_streams", "v:0",
			"-show_entries", "stream=width",
			"-of", "csv=p=0",
			path,
		).Output()

		width := 0
		fmt.Sscanf(strings.TrimSpace(string(out)), "%d", &width)

		if width > 3840 {
			exec.Command("ffmpeg",
				"-i", path,
				"-vf", "scale=3440:-1",
				"-q:v", "2",
				staticCache, "-y",
			).Run()
		} else {
			if err := copyFile(path, staticCache); err != nil {
				fmt.Fprintln(os.Stderr, "copy failed:", err)
				os.Exit(1)
			}
		}

		exec.Command("pkill", "-x", "swaybg").Run()
		exec.Command("qs", "ipc", "call", "root", "wallType", "1").Run()
		exec.Command("wallust", "-s", "run", staticCache).Run()

		saveState("image", path, cfg.State.Shader)
	}
}

func cmdSetShader(shaderName string) {
	cfg := loadConfig()
	exec.Command("qs", "ipc", "call", "root", "wallType", "2").Run()
	exec.Command("qs", "ipc", "call", "root", "wallShader", shaderName).Run()
	saveState("shader", cfg.State.Wallpaper, shaderName)
}

// ─── Утилиты ────────────────────────────────────────────────────────────────

func copyFile(src, dst string) error {
	data, err := os.ReadFile(src)
	if err != nil {
		return err
	}
	return os.WriteFile(dst, data, 0644)
}

// ─── Main ────────────────────────────────────────────────────────────────────

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: wallpaper-picker <list-images|list-videos|list-shaders [dir]|get-state|cache-all|clean-cache|set <path>|set-shader <name>>")
		os.Exit(1)
	}

	parseIntArg := func(idx int) int {
		if len(os.Args) > idx {
			v := 0
			fmt.Sscanf(os.Args[idx], "%d", &v)
			return v
		}
		return 0
	}

	switch os.Args[1] {
	case "list-images":
		cmdListImages(parseIntArg(2), parseIntArg(3))
	case "list-videos":
		cmdListVideos(parseIntArg(2), parseIntArg(3))
	case "list-shaders":
		dir := ""
		if len(os.Args) >= 3 {
			dir = os.Args[2]
		}
		cmdListShaders(dir)
	case "get-state":
		cmdGetState()
	case "cache-all":
		cmdCacheAll()
	case "clean-cache":
		cmdCleanCache()
	case "set":
		if len(os.Args) < 3 {
			fmt.Fprintln(os.Stderr, "set requires <path>")
			os.Exit(1)
		}
		cmdSet(os.Args[2])
	case "set-shader":
		if len(os.Args) < 3 {
			fmt.Fprintln(os.Stderr, "set-shader requires <shader-name>")
			os.Exit(1)
		}
		cmdSetShader(os.Args[2])
	default:
		fmt.Fprintln(os.Stderr, "unknown command:", os.Args[1])
		os.Exit(1)
	}
}
